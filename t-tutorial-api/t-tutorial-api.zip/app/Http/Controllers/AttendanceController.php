<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function __construct(Request $req)
    {
        $this->middleware('auth:api');
    }

    public function markAttendance(Request $req)
    {
    }

    public function getAttendanceReport(Request $req)
    {
    }
}
