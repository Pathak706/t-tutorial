<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notes;

class NotesController extends Controller
{
    public function __construct(Request $req)
    {
        $this->middleware('auth:api');
    }

    public function index(Request $req)
    {
        try {
            $notes = Notes::all();
            return response()->json(array('status' => true, 'message' => 'all notes fetched.', 'data' => [$notes] ));
        } catch (Exception $e) {
            return response()->json(array('status' => false, 'message' => 'Error fetching notes.', 'data' => [] ));
        }
    }

    public function upload(Request $req)
    {
        $imageName = $request->input('notes');
        if($request->hasfile( $imageName)){
            $file =$request->file($imageName);
            $extension =$file->extension();   //getting Images_during_install extension
            $filename = $imageName.'_'.$id.'_'.time().'_'.rand(0000 , 9999).'.'.$extension;
            $file->move('uploads/Installation/',$filename);
            $notes = new Notes();
            $notes->notes_name = $file->getOriginalClientName();
            $notes->file_path =$filename;
            $notes->save();
            return response()->json(array('status' => true, 'message' => 'document uploaded.', 'data' => $notes ));
        }
    }
}
