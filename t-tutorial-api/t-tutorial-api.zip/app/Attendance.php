<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    //
    protected $fillable = [
        'id',
        'faculty_id',
        'student_id',
        'course_batch',
        'lecture',
        'timetable_id',
        'created_at',
        'updated_at',
    ];

    public function markAttendance()
    {
        return $this->belongsTo('App\User', 'faculty_id');
    }

    public function getAttendance()
    {
        return $this->belongsTO('App\User', 'student_id');
    }

    public function get_lecture()
    {
        return $this->belongsTo('App\Timetable', 'timetable_id');
    }
}
