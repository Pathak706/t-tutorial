<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnrollToCourse extends Model
{
    protected $fillable = [
        'id',
        'course_batch',
        'student_id',
        'created_at',
        'updated_at',
    ];

    public function get_course()
    {
        return $this->belongsTo('App\Course', 'course_batch');
    }

    public function get_timetable()
    {
        return $this->belongsTo('App\Timetable', 'course_batch');
    }
}
